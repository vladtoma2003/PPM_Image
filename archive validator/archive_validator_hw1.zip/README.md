# Archive validator for homeworks

Please run this command before the first use:
	pip install deepdiff

## Usage

`python3 archive_validator.py <archive_name>`

## Yaml config

In order to validate the homework, you should have a `ref.yaml` file that specifies the format of the archive.
